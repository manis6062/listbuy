<?
############ Database table define#######################
define(ADMIN,"tbl_admin");

define(CONFIG,"tbl_config");

define(CATEGORY,"tbl_category");

define(STATE,"tbl_state");

define(COUNTRY,"tbl_country");

define(STATICCMS,"tbl_static_cms");

define(NEWSLETTER,"tbl_newsletter");

define(USERNEWSLETTER,"tbl_user_newsletter");

define(ADVERTISE,"tbl_add");

define(BIN,"tbl_bin");

define(USER,"tbl_user");

define(BLOG,"tbl_blog");

define(BLOG_COMMENT,"tbl_blogcomment");
 
define(QUESTION,"tbl_question");

define(TRANSACTION,"tbl_transaction");

define(PROPOSAL,"tbl_proposal");

define(INBOX,"tbl_inbox");

define(OUTBOX,"tbl_outbox");

define(CREDIT,"tbl_credit");

define(USER_FEEDBACK,"tbl_user_feedback");

define(SHORTLIST,"tbl_shortlist");

define(ATTACHMENTS,"tbl_attachments");

define(TERM_VIOLATION,"tbl_violation");

define(SITE_STATUS,"tbl_site_status");
#######################################################
?>