<?
	require_once('../config/config.php');	
	validation_check($_SESSION['user_id'], '../index.php');
?>
