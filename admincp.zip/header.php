<div id="header_image" >
<!--table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#000000"><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="498"><img src="images/flippa-clone_07.jpg" width="498" height="143" /></td>
            <td align="center">Welcome to the new Domain Market place! </td>
          </tr>
          <tr>
            <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
              <tr>
                <td>buy &amp; sell<br />
                  websites</td>
                </tr>
              <tr>
                <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</td>
                </tr>
            </table></td>
            <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
              <tr>
                <td><table width="100%" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <td width="6%"><img src="images/flippa-clone_13.jpg" width="20" height="19" /></td>
                    <td width="94%" class="header_text_check">No buyer fees</td>
                  </tr>
                  <tr>
                    <td><img src="images/flippa-clone_13.jpg" width="20" height="19" /></td>
                    <td class="header_text_check">No Hidden Fees</td>
                  </tr>
                  <tr>
                    <td><img src="images/flippa-clone_13.jpg" width="20" height="19" /></td>
                    <td class="header_text_check">Zero &ldquo;Success Fees&rdquo;</td>
                  </tr>
                  <tr>
                    <td><img src="images/flippa-clone_13.jpg" width="20" height="19" /></td>
                    <td class="header_text_check">$0.00 - 30 Day Listing Fee</td>
                  </tr>
                </table></td>
                <td width="171"><img src="images/flippa-clone_10.jpg" width="171" height="162" /></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td class="header_reg_link"><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="right"><img src="images/flippa-clone_17.jpg" width="465" height="36" /></td>
      </tr>
    </table></td>
  </tr>
</table-->

  
  </div>