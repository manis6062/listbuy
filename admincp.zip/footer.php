<div id="footer" > 
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#FFFFFF" style="padding:15px;"></td>
  </tr>
  <tr>
    <td class="footer_bg1">


<table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" valign="top">&nbsp;</td>
    </tr>
  <tr>
    <td align="center" valign="top">
    
    
   <div align="center"><a href="about-us.php">Company</a>&nbsp;&nbsp;|&nbsp;  <a href="registration.php">Free Registration</a>&nbsp;&nbsp;|&nbsp; <a href="how-itworks.php">How It Works</a>&nbsp;&nbsp;|&nbsp; <a href="contact-us.php">Contact Us</a>&nbsp;&nbsp;|&nbsp; <a href="legal-disclaimer.php">Legal Notice</a></div>
</td>
  </tr>
  <tr>
    <td align="center" valign="top">
<div id="footer2"><p><br />Copyright 2013.&nbsp;<strong>&nbsp;ListBuyDomains.com</strong><span style="color: #33cccc;"><span style="color: #ff0000;">&nbsp;</span></span><span style="color: #0000ff;"><span style="color: #33cccc;"><span style="color: #ff0000;">From Domainer for Domainers</span></span> </span><br /><em><span style="font-size: small;"><strong>List &amp; Buy Domains and Web Sites!</strong>&nbsp;</span></em><a title="PHP Scripts" href="http://www.zeescripts.com" target="_blank"></a></p></div></td>
  </tr>
  
</table>






</td>
  </tr>
</table>

</div>