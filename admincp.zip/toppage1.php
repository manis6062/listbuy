<div id="header_image" >
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#385845"><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>
        
        
        <div class="menu_top">
<? include_once("top-menu.php")?>
</div>
        
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF"><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="349" height="70"><a href="index.php"><img src="images/logo2.jpg" border="0" /></a></td>
            <td width="636" align="left" class="header_txt4">Domain & Website Marketplace, where you can Buy & List domains!</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td class="header_reg_link"><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="right" height="36"><? if($_SESSION['user_id']==""){?><a href="registration.php"></a><? }?></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>

  
  </div>