<div class="clear-padding"></div>
<?=statica_cms_page_value(17)?>
<div class="clear-padding"></div>