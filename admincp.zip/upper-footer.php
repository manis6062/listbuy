<div class="banner_bg">
<center><?=statica_cms_page_value(20)?></center>
</div>
