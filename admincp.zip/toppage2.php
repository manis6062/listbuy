<div id="header_image" >
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#385845"><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>
        
        
        <div class="menu_top">
<? include_once("top-menu.php")?>
</div>
        
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF"><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="498"><a href="index.php"><img src="../images/logo/logo.jpg" width="498" height="143" border="0" /></a></td>
            <td width="498" align="left" class="header_txt4">Welcome to our new Domain and Website Marketplace! 
              You can find hundreds of domains for sale at any given time!</td>
          </tr>
          <tr>
            <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
              <tr>
                <td><div class="header_txt1">Buy &amp; Sell</div>
                 <div class="header_txt2"> Domains</div></td>
                </tr>
              <tr>
                <td class="header_txt3">List Buy Domains is a website which allows users to LIST and BUY both established and new websites or domains. Unlike other websites, there is no commission or other hidden success fee. </td>
                </tr>
            </table></td>
            <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
              <tr>
                <td><table width="91%" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <td width="6%"><img src="images/lbd_13.jpg" width="20" height="19" /></td>
                    <td width="94%" class="header_text_check">No buyer fees</td>
                  </tr>
                  <tr>
                    <td><img src="images/lbd_13.jpg" width="20" height="19" /></td>
                    <td class="header_text_check">No Hidden Fees</td>
                  </tr>
                  <tr>
                    <td><img src="images/lbd_13.jpg" width="20" height="19" /></td>
                    <td class="header_text_check">Zero &ldquo;Success Fees&rdquo;</td>
                  </tr>
                  <tr>
                    <td><img src="images/lbd_13.jpg" width="20" height="19" /></td>
                    <td class="header_text_check">Sign up for Free!</td>
                  </tr>
                </table></td>
                <td width="171"><a href="newlisting.php"><img src="images/lbd_10.jpg" border="0" /></a></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td class="header_reg_link"><table width="985" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="right" height="36"><? if($_SESSION['user_id']==""){?><a href="registration.php"><img src="images/lbd_17.jpg" width="465" height="36" border="0" /></a><? }?></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>

  
  </div>