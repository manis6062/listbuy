<?
require_once('config/config.php');
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td align="left" valign="top"><h3><?=static_cms_title(16)?></h3></td>
  </tr>
  <tr>
    <td align="left" valign="top"><?=statica_cms_page_value(16)?></td>
  </tr>
</table>
