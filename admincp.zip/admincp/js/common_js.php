<script language="javascript" src="../js/validate_email.js"></script>
<script language="javascript" src="../js/side_scripts.js"></script>
<script language="javascript" src="../js/CalendarPopup.js"></script>
<script language="javascript" src="../js/ajax_state.js"></script>
